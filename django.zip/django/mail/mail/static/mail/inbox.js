document.addEventListener('DOMContentLoaded', function() {

  // Use buttons to toggle between views
  document.querySelector('#inbox').addEventListener('click', () => load_mailbox('inbox'));
  document.querySelector('#sent').addEventListener('click', () => load_mailbox('sent'));
  document.querySelector('#archived').addEventListener('click', () => load_mailbox('archive'));
  document.querySelector('#compose').addEventListener('click', compose_email);

  // By default, load the inbox
  load_mailbox('inbox');
});

function compose_email() {

  // Show compose view and hide other views
  document.querySelector('#emails-view').style.display = 'none';
  document.querySelector('#email-view').style.display = 'none';
  document.querySelector('#compose-view').style.display = 'block';

  // Clear out composition fields
  document.querySelector('#compose-recipients').value = '';
  document.querySelector('#compose-subject').value = '';
  document.querySelector('#compose-body').value = '';

  document.querySelector('#compose-form').onsubmit = function() {
    // Get the required parameters for the API call
    const recipients = document.querySelector('#compose-recipients').value;
    const subject = document.querySelector('#compose-subject').value;
    const body = document.querySelector('#compose-body').value;

    //console.log(recipients + ' ' + subject + ' ' + body);

    // Call the API
    fetch('/emails', {
      method: 'POST',
      body: JSON.stringify({
        recipients: recipients,
        subject: subject,
        body: body
      })
    })
    .then(response => response.json())
    .then(result => {
      // Print result
      console.log(result);
    });

    // After sending the email, take the user to the sent mailbox
    load_mailbox('sent');

    // Return false because we don't want to send the form to another page
    return false;
  }
}

function load_mailbox(mailbox) {
  
  // Show the mailbox and hide other views
  document.querySelector('#emails-view').style.display = 'block';
  document.querySelector('#compose-view').style.display = 'none';
  document.querySelector('#email-view').style.display = 'none';

  // Show the mailbox name
  document.querySelector('#emails-view').innerHTML = `<h3>${mailbox.charAt(0).toUpperCase() + mailbox.slice(1)}</h3>`;

  // Call the API for the respective mailbox
  fetch('/emails/' + mailbox)
  .then(response => response.json())
  .then(emails => {
    // Print emails
    //console.log(emails);

    // Do something with the emails
    emails.forEach(function(email) {
      const element = document.createElement('div');
      element.style.cssText = 'border: 1px solid black;'
      if (email.read) {
        element.style.cssText = 'border: 1px solid black; background-color: grey';
      }
      element.addEventListener('click', function() {
        // API Call to mark the email as read
        fetch('/emails/' + email.id, {
          method: 'PUT',
          body: JSON.stringify({
            read: true
          })
        })

        // API Call to view the email in detail
        fetch('/emails/' + email.id)
        .then(response => response.json())
        .then(email_detail => {
          load_email(email_detail);
        })
      })
      element.innerHTML = email.sender + " " + email.subject + " " + email.timestamp;

      // Fully working code upto this line
      // if the mailbox is not sent
      if (mailbox !== 'sent') {
        // add a button
        const button = document.createElement('button');
        // set the button's value based on email's archived state
        if (email.archived) {
          button.innerHTML = 'Unarchive';
        }
        else {
          button.innerHTML = 'Archive';
        }

        // when the button is clicked archive or unarchive the button
        button.addEventListener('click', function() {
          if (email.archived) {
            unarchive_email(email.id);
          }
          else {
            archive_email(email.id);
          }

          // load the inbox after doing that
          load_mailbox('inbox');
        })

        document.querySelector('#emails-view').append(button);
      }
      // Fully working code from this line to end
      document.querySelector('#emails-view').append(element);
    })
  })
}

function load_email(email) {

  // Show the email-view and hide other views
  document.querySelector('#emails-view').style.display = 'none';
  document.querySelector('#compose-view').style.display = 'none';
  document.querySelector('#email-view').style.display = 'block';

  // Clear the previous values
  document.querySelector('#email-sender').innerHTML = '';
  document.querySelector('#email-recipients').innerHTML = '';
  document.querySelector('#email-subject').innerHTML = '';
  document.querySelector('#email-timestamp').innerHTML = '';

  // Append the headers
  document.querySelector('#email-sender').innerHTML = `<b>From: </b> ${email.sender}`;
  document.querySelector('#email-recipients').innerHTML = `<b>To: </b> ${email.recipients}`;
  document.querySelector('#email-subject').innerHTML = `<b>Subject: </b> ${email.subject}`;
  document.querySelector('#email-timestamp').innerHTML = `<b>Timestamp: </b> ${email.timestamp}`;

  document.querySelector('#email-message').innerHTML = email.body;

  // We have to take the user to the email compose form when the user clicks the Reply button
  // Reply button's id is email-reply
  const reply_button = document.querySelector('#email-reply');
  reply_button.addEventListener('click', function() {

    // Take the user to the email compose form
    //console.log(email);
    compose_email_reply(email);
  })
}

function unarchive_email(id) {
  // API Call to unarchive the email
  fetch('/emails/' + id, {
    method: 'PUT',
    body: JSON.stringify({
      archived: false
    })
  })
}

function archive_email(id) {
  // API Call to archive the email
  fetch('/emails/' + id, {
    method: 'PUT',
    body: JSON.stringify({
      archived: true
    })
  })
}

function compose_email_reply(email) {
  //console.log(email);

  // Set the views, only compose-email view should show up like in compose_email()
  // Show only compose-view hide other views
  document.querySelector('#emails-view').style.display = 'none';
  document.querySelector('#email-view').style.display = 'none';
  document.querySelector('#compose-view').style.display = 'block';

  // Works

  // This reply email should only be sent to the sender of the email
  // email.sender is the sender
  // compose-recipients is the input field for the destination email
  // first disable the input field
  const recipients_field = document.querySelector('#compose-recipients');
  //recipients_field.disabled = true;

  // Works

  // Write the email address of the sender to the recipients_field
  recipients_field.value = email.sender;

  // Works

  // We also want to pre-fill the subject field
  // Get the subject field
  const subject_field = document.querySelector('#compose-subject');
  // Disable the subject field
  //subject_field.disabled = true;
  // Check if the email's subject already has "Re: " or not
  // Get the first 3 characters of the subject
  const three = email.subject.slice(0, 4);
  // Convert to lowercase
  three.toLowerCase();
  let newSubject = '';
  if (three !== 're: ') {
    newSubject = newSubject + 'Re: ';
  }

  // Append the old subject
  // Now if the old subject had a "Re: "
  // if will not execute so we will have ""
  // "" + email.subject will be correct
  // Now if the old subject didnt have a "Re: "
  // we will add that
  // and append the subject
  newSubject = newSubject + email.subject;
  // Finally add it to the subject field
  subject_field.value = newSubject;

  //Pre-fill the body field
  message_field = document.querySelector('#compose-body');
  message_field.value = email.body;

  // Post the email
  document.querySelector('#compose-form').onsubmit = function() {
    // Get the destination email
    const recipients = document.querySelector('#compose-recipients').value;
    // Get the subject
    const subject = document.querySelector('#compose-subject').value;
    // Get the body
    const body = document.querySelector('#compose-body').value;

    // API Call to send the email
    fetch('/emails', {
      method: 'POST',
      body: JSON.stringify({
        recipients: recipients,
        subject: subject,
        body: body
      })
    })
    .then(response => response.json())
    .then(result => {
      // Print result
      console.log(result);
    })

    load_mailbox('sent');

    return false;
  }
}